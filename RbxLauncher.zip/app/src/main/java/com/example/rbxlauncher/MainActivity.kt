package com.example.rbxlauncher

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

data class AppTheme(
    val name: String, val bg: Int, val panel: Int, val accent: Int,
    val text: Int, val title: Int, val light: Boolean
)

private fun c(s: String) = Color.parseColor(s)

val THEMES = listOf(
    AppTheme("Midnight", c("#0B1640"), c("#14235F"), c("#3B5BDB"), c("#E8ECFF"), c("#FFFFFF"), false),
    AppTheme("Bubblegum", c("#FFE0EF"), c("#FFC8E3"), c("#FF8FC8"), c("#5A2A45"), c("#FF6FB5"), true),
    AppTheme("Cream", c("#FBF3DC"), c("#EFE6CF"), c("#B7CFD6"), c("#5B5340"), c("#5BA4D6"), true),
    AppTheme("Ocean", c("#0F3C8F"), c("#1A4FB0"), c("#2F6BDB"), c("#FFFFFF"), c("#FFFFFF"), false)
)

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private var font: Typeface = Typeface.DEFAULT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        font = try { Typeface.createFromAsset(assets, "fonts/custom.ttf") } catch (e: Exception) { Typeface.DEFAULT }
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            typeface = if (bold) Typeface.create(font, Typeface.BOLD) else font
        }

    @Suppress("DEPRECATION")
    private fun render() {
        val t = THEMES[prefs.getInt("theme", 0).coerceIn(0, THEMES.lastIndex)]
        window.statusBarColor = t.bg
        window.navigationBarColor = t.bg
        window.decorView.systemUiVisibility = if (t.light)
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        col.addView(label("Roblox", 30f, t.title, true))
        col.addView(label("LAUNCHER", 13f, t.text))

        val play = Button(this).apply {
            text = "PLAY"; textSize = 20f; typeface = font; isAllCaps = false
            setTextColor(if (t.light) t.text else Color.WHITE)
            background = box(t.accent, 18)
            setOnClickListener { launchRoblox() }
        }
        col.addView(play, LinearLayout.LayoutParams(-1, dp(72)).apply { topMargin = dp(28); bottomMargin = dp(28) })

        col.addView(label("THEME", 13f, t.text))
        THEMES.forEachIndexed { i, th ->
            val selected = th == t
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                background = box(t.panel, 14, if (selected) 2 else 0, t.accent)
                setOnClickListener { prefs.edit().putInt("theme", i).apply(); render() }
            }
            val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(th.bg, th.panel, th.accent).forEach { colr ->
                sw.addView(View(this).apply { background = box(colr, 6, 1, t.text) },
                    LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginEnd = dp(6) })
            }
            card.addView(sw)
            card.addView(label(th.name, 16f, t.text, selected),
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(t.bg); isFillViewport = true; addView(col)
        })
    }

    private fun launchRoblox() {
        val i = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (i != null) startActivity(i)
        else {
            Toast.makeText(this, "Roblox isn't installed", Toast.LENGTH_SHORT).show()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.roblox.client")))
        }
    }
}
